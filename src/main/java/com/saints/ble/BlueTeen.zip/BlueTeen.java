package com.saints.ble;

import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothProfile;
import android.util.Log;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.os.Handler;

import com.saints.Thread.InputThread;

import java.util.UUID;


public class BlueTeen {
    private Context context;
    private BluetoothManager manager;
    private BluetoothAdapter adapter;
    private BluetoothDevice klbDevice;
    private BluetoothGatt gatt;

//    private static final UUID serverUuid = UUID.fromString("0003cdd0-0000-1000-8000-00805f9b0131");
//    private static final UUID notifyUuid = UUID.fromString("0003cdd1-0000-1000-8000-00805f9b0131");
//    private static final UUID writeUuid = UUID.fromString("0003cdd2-0000-1000-8000-00805f9b0131");
    private static final UUID UUID_CLIENT_CHARACTERISTIC_CONFIG_DESCRIPTOR = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");



    public BlueTeen(Context ctx) {
        context = ctx;
        manager =(BluetoothManager)context.getSystemService(Context.BLUETOOTH_SERVICE);
        adapter = manager.getAdapter();
    }

    public String connect() {
        if(!adapter.isEnabled()) {
            return "not open";
        }
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                adapter.stopLeScan(scanCallback);
            }
        }, 1000 * 30);
        adapter.startLeScan(scanCallback);
        return "";
    }

    public boolean unconnect() {
        if (gatt != null) {
            gatt.disconnect();
            gatt.close();
            gatt = null;
            return true;
        }
        return false;
    }

    private boolean enableNotifyCharacteristic(BluetoothGattCharacteristic characteristic, boolean enable) {
        //根据通知UUID找到通知特征
        boolean success = gatt.setCharacteristicNotification(characteristic, enable);
        if(!success) {
            return false;
        }
        BluetoothGattDescriptor descriptor = characteristic.getDescriptor(UUID_CLIENT_CHARACTERISTIC_CONFIG_DESCRIPTOR);
        if(descriptor == null) {
            return false;
        }
        descriptor.setValue(enable ? BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE : BluetoothGattDescriptor.DISABLE_NOTIFICATION_VALUE);
        return gatt.writeDescriptor(descriptor);
    }

    private BluetoothAdapter.LeScanCallback scanCallback = new BluetoothAdapter.LeScanCallback(){
        @Override
        public void onLeScan(final BluetoothDevice device, int rssi, byte[] scanRecord) {
            if(klbDevice == null) {
                String name = device.getName();
                if (name !=null && name.indexOf("KLB") == 0) { //name
                    klbDevice = device;
                    gatt = device.connectGatt(context, false, gattCallback);
                }
            }
        }
    };

    private BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status,int newState){
            super.onConnectionStateChange(gatt, status, newState);

            if (newState == BluetoothProfile.STATE_CONNECTED) {
                // 连接成功 发现服务
                gatt.discoverServices();
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                // 连接断开
                Log.d("TAG","onConnectionStateChange fail-->" + status);
            } else {
                // 连接断开
                Log.d("TAG","onConnectionStateChange fail-->" + status);
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            super.onServicesDiscovered(gatt, status);
            if (status == BluetoothGatt.GATT_SUCCESS) {
                //发现设备，遍历服务，初始化特征
                for (BluetoothGattService gattService : gatt.getServices()) {
                    for (BluetoothGattCharacteristic gattCharacteristic : gattService.getCharacteristics()) {
                        int charaProp = gattCharacteristic.getProperties();
                        if ((charaProp & BluetoothGattCharacteristic.PROPERTY_NOTIFY) > 0) {
                            //根据通知UUID找到通知特征
                            boolean success = enableNotifyCharacteristic(gattCharacteristic, true);
                            if(!success) {
                                Log.d("TAG", "enableNotifyCharacteristic fail-->" + success);
                            }
                        }
                    }
                }
                String address = klbDevice.getAddress();
            } else {
                Log.d("TAG","onServicesDiscovered fail-->" + status);
            }
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status){
            super.onCharacteristicRead(gatt, characteristic, status);
            if (status == BluetoothGatt.GATT_SUCCESS) {
                // 收到的数据
                receiveData(characteristic.getValue());
            }else{
                Log.d("TAG","onCharacteristicRead fail-->" + status);
            }
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt,BluetoothGattCharacteristic characteristic){
            super.onCharacteristicChanged(gatt, characteristic);
            //当特征中value值发生改变
            receiveData(characteristic.getValue());
        }

        /**
         * 收到BLE终端写入数据回调
         * @param gatt
         * @param characteristic
         * @param status
         */
        @Override
        public void onCharacteristicWrite(BluetoothGatt gatt,BluetoothGattCharacteristic characteristic, int status) {
            super.onCharacteristicWrite(gatt, characteristic, status);
            if (status == BluetoothGatt.GATT_SUCCESS) {
                // 发送成功

            } else {
                // 发送失败
            }
        }

        @Override
        public void onDescriptorWrite(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
            super.onDescriptorWrite(gatt, descriptor, status);
            if (status == BluetoothGatt.GATT_SUCCESS) {

            }
        }

        @Override
        public void onReadRemoteRssi(BluetoothGatt gatt, int rssi, int status) {
            super.onReadRemoteRssi(gatt, rssi, status);
            if (status == BluetoothGatt.GATT_SUCCESS) {

            }
        }

        @Override
        public void onDescriptorRead(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
            super.onDescriptorRead(gatt, descriptor, status);
            if (status == BluetoothGatt.GATT_SUCCESS) {

            }
        }
    };

    private void receiveData(byte[] data) {
        int keyCode = -1;
        if(data.length==3 && ((int)data[0]) == -6 && ((int)data[2]) == -5) {
            int num = (int)data[1];
            if(num>=0x30 && num<=0x39) {
                keyCode = num - 41;
            } else if(num>=0x41 && num<=0x5A) {
                keyCode = num - 36;
            }
        }
        Log.d("TAG", "receive-->" + data.length);
        if(keyCode >= 0) {
            Thread thread = new InputThread(keyCode);
            thread.start();
        }
    }
}
